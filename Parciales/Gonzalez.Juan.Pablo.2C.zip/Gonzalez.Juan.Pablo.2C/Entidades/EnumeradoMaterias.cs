﻿public enum EMateria
{
    Programacion,
    Laboratorio
};