namespace PrimerParcial
{
    public partial class frnABMInscripcionAlumno : Form
    {
        public frnABMInscripcionAlumno()
        {
            InitializeComponent();
        }
    }
}